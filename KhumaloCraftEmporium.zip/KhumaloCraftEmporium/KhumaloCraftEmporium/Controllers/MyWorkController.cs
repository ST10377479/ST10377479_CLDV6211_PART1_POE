﻿using Microsoft.AspNetCore.Mvc;

namespace KhumaloCraftEmporium.Controllers
{
    public class MyWorkController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult About()
        {
            return View();
        }

        public IActionResult Contact()
        {
            return View();
        }
        public IActionResult HisWork()
        {
            return View(); 
        }

    }
}
